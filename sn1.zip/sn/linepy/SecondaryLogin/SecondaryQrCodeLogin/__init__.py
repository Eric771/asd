__all__ = ['ttypes', 'constants', 'SecondaryQrCodeLoginService', 'SecondaryQrCodeLoginPermitNoticeService']
